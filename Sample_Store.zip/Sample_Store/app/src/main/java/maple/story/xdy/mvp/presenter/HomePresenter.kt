package maple.story.xdy.mvp.presenter

import maple.story.xdy.activity.HomeActivity
import maple.story.xdy.mvp.modle.HomeModle
import maple.story.xdy.mvp.base.BasePresenter

/**
 * Created by XP on 2017/11/27.
 */
class HomePresenter: BasePresenter<HomeActivity, HomeModle>(){

}