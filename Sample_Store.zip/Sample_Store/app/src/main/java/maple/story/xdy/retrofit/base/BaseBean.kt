package maple.story.xdy.retrofit.base

/**
 * Created by XP on 2017/11/27.
 */
open class BaseBean{
}