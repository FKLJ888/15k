package maple.story.xdy.mvp.modle

import maple.story.xdy.mvp.base.BaseModle

/**
 * Created by XP on 2017/11/27.
 */
class FindModle : BaseModle() {
}