package maple.story.xdy.mvp.contract

/**
 * Created by XP on 2017/11/27.
 */
abstract class FindContract {
    interface FindView{

    }
    interface FindPresenter{

    }
    interface FindModle{

    }
}