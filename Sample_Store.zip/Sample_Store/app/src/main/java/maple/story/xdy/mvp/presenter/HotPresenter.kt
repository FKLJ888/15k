package maple.story.xdy.mvp.presenter

import maple.story.xdy.fragment.FindFragment
import maple.story.xdy.fragment.HotFragment
import maple.story.xdy.mvp.base.BasePresenter
import maple.story.xdy.mvp.modle.FindModle
import maple.story.xdy.mvp.modle.HotModle

/**
 * Created by XP on 2017/11/27.
 */
class HotPresenter : BasePresenter<HotFragment, HotModle>(){

}