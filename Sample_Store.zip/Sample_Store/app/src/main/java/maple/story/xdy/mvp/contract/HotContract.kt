package maple.story.xdy.mvp.contract

/**
 * Created by XP on 2017/11/27.
 */
abstract class HotContract {
    interface HotView{

    }
    interface HotPresenter{

    }
    interface HotModle{

    }
}